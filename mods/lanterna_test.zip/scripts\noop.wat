(module
  (func (export "noop"))
)